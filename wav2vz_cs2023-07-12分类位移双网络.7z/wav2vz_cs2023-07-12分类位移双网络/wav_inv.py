# 可以检测与计算音频文件的RMS值，并分割出单个的录音文件
# mamba install scipy numpy matplotlib
import os
import scipy.io.wavfile as wavfile
import numpy as np

'''
import torchaudio
import matplotlib.pyplot as plt

def plot_audio(filename):
    waveform, sample_rate = torchaudio.load(filename)

    print("Shape of waveform: {}".format(waveform.size()))
    print("Sample rate of waveform: {}".format(sample_rate))

    plt.figure()
    plt.plot(waveform.t().numpy())

    return waveform, sample_rate
'''

'''
-1.0        +1.0        float32
-2147483648 +2147483647 int32       32-bit integer
-2147483648 +2147483392 int32       24-bit integer
-32768      +32767      int16
0           255         uint8
'''

from wav_tools import *


pathsep=os.path.sep
in_filepath = "./wav_files_split" #输入路径
out_filepath = "./wav_files_inv" #输出路径
filename_lst = os.listdir(in_filepath) #得到文件夹下的所有文件名称

for base_name in filename_lst:
    fn = in_filepath+pathsep+base_name
    file_name, fn_ext = os.path.splitext(base_name)
    if not os.path.isfile(fn): continue
    if fn_ext.lower()!=".wav": continue
    print(fn)
    wav_data, sample_rate, n_channels, n_frames = wavfile_read(fn)
    #sample_rate, wav_data = wavfile.read(in_filepath+pathsep+base_name)
    print("采样率: {} 数据量: {} 通道：{} 数据格式: {} 时间: {} 秒".format(sample_rate, wav_data.shape, n_channels, wav_data.dtype, n_frames//sample_rate))

    # 只处理第一个声道
    if n_channels>1:
        wav_data = wav_data[:,0]

    # 读取音频文件
    time_length = n_frames / sample_rate

    #print(wav_data)
    #print(wav_data.dtype, wav_data.shape, wav_data.min(), wav_data.max(), n_frames, sample_rate, time_length)


    wav_data = np_data_invert(wav_data)

    fn = "%(fn)s.inv%(ext)s"%{"fn":file_name, "ext":fn_ext}
    fn = out_filepath+pathsep+fn
    print(fn)
    wavfile.write(fn, sample_rate, wav_data)
