'''
# Brian Murray, brian@proximity.com.au
# 参考了 VZREAD.C

一、录音磁带的格式
波形图见
数据磁带机.png
LASER310_cas_0xAA_Figure.png

读入的字节依次为：
同步和前导：128个 或 (LASER310)255个 0x80 5个 0xFE
程序类型：1字节 TYPE
程序文件名：17字节 FILENAME
程序开始： 2字节 START
程序结束：2字节 END
程序数据：
求和校验值：
结尾：0x00 1个字节 或 (LASER310)20个, 没有该字节不影响读取

录音末尾是求和校验值
计算方法是 0xFF00 或 0x0000 、文件开始（高低字节）、文件结尾（高低字节）、数据，求和后取低16位。
LASER310 是 0x0000

在读入文件名后，约有0.003秒的静音。这段时间应该是留给程序显示文件名用的。
长度约 555us x 5.5

二、vz 文件格式
VZF_MAGIC : 4个字节 0x20 0x20 0x00 0x00 或者是 0x56 0x5A 0x46 0x30
vzf_filename : 17个字节 最后一个字节必须为零，末尾不足的字符用空格0x20代替
vzf_type : 1个字节 同磁带
vzf_startaddr : 2个字节 程序开始地址
之后是数据
后是数据

# VZREAD.C中的算法是采样最小值到最大值的距离，来判断波长。
# 问题是方波的最小值和最大值的位置不稳定，特别是高精度采样时。

'''

# 用 list 或 dict 存贮标志位置和值，会带来复杂的数据操作。
# 直接用于snd 一一对应的list来存储标志
# mark_a = [ gv.m_unset for _ in range(len(snd))]

import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
import os
#import struct

#from pylab import *
from scipy.io import wavfile
from scipy.fftpack import fft
#import scipy.ndimage.filters as filt
#from scipy import ndimage
#import scipy.ndimage.uniform_filter as filt

#import tkinter as tk

from wav_tools import *
from plt_tools import *

import gv
from gv_func import *

import PySimpleGUI as sg

#jsonlines-3.1.0
import jsonlines
import argparse

#verbose=False
verbose=True

os.environ['KMP_DUPLICATE_LIB_OK'] ='TRUE'

mark_s_a = []

def dat_mark_s(k,*args):
    global mark_s_a

    for v in args:
        mark_s_a[k] = v
        k = k+gv.chunk

def mark_s_flag(m):
    s='?'
    if m==0: s='e'
    if m==1: s='d'
    if m==2: s='c'
    if m==3: s='b'
    if m==4: s='a'
    if m==5: s='M'
    if m==6: s='A'
    if m==7: s='B'
    if m==8: s='C'

    return s

def mark_s_text(m):
    s='_'
    if m==0: s='-5'
    if m==1: s='-4'
    if m==2: s='-3'
    if m==3: s='-2'
    if m==4: s='-1'
    if m==5: s='M'
    if m==6: s='+1'
    if m==7: s='+2'
    if m==8: s='+3'
    return s

def dat_mark_s_text(pos):
    global mark_s_a
    mark = mark_s_a[pos]
    s=mark_s_text(mark)
    return "%s"%(s)

def dat_mark_s_save():
    global mark_s_a, idx_s_fn

    if len(mark_s_a)==0: return 0;

    cnt = 0
    with jsonlines.open(idx_s_fn, mode='w') as writer:
        for k in range(len(mark_s_a)):
            v = mark_s_a[k]
            if v!=gv.m_unset:
                #print(k,v)
                writer.write({k:v})
                cnt += 1

    return cnt


mark_a = []

snd=None

clip_len = 0

def dat_mark(k,*args):
    global mark_a

    for v in args:
        mark_a[k] = v
        k = k+gv.chunk

def blk_mark(k,v,l):
    global mark_a

    for i in range(l):
        mark_a[k+i] = v

def mark_text(m):
    s='unset'
    if m==gv.m_unk: s='unk'
    if m==gv.m_blk: s='blk'
    if m==gv.m_0: s='0'
    if m==gv.m_1: s='1'
    return s

def mark_flag(m):
    s='?'
    if m==gv.m_unk: s='u'
    if m==gv.m_blk: s='b'
    if m==gv.m_0: s='0'
    if m==gv.m_1: s='1'
    return s

def dat_mark_text(pos):
    global mark_a
    mark = mark_a[pos]
    s=mark_text(mark)
    return "%d%% pos %d : %s"%(pos*100//len(mark_a),pos,s)

def dat_mark_save():
    global mark_a, idx_fn

    if len(mark_a)==0: return 0;

    cnt = 0
    with jsonlines.open(idx_fn, mode='w') as writer:
        for k in range(len(mark_a)):
            v = mark_a[k]
            if v!=gv.m_unset:
                #print(k,v)
                writer.write({k:v})
                cnt += 1

    return cnt

def draw_mark(ax, view_pos, mark_pos, view_len, chunk, dmin, dmax):
    global mark_a

    lst_unk=[]
    lst_blk=[]
    lst_0=[]
    lst_1=[]
    #print(view_pos, view_len)
    for i in range(view_len):
        mark = mark_a[view_pos+i]
        if mark==gv.m_unk: lst_unk.append(i)
        if mark==gv.m_blk: lst_blk.append(i)
        if mark==gv.m_0: lst_0.append(i)
        if mark==gv.m_1: lst_1.append(i)

    div = list(range(0,view_len,chunk))
    '''
    https://matplotlib.org/stable/tutorials/colors/colors.html
    'b' as blue
    'g' as green
    'r' as red
    'c' as cyan
    'm' as magenta
    'y' as yellow
    'k' as black
    'w' as white
    '#C0C0C0'
    '''
    ax.vlines(div, dmin, dmax, linestyles='dashed', colors='silver')

    ax.vlines(lst_unk, dmin, dmax, linestyles='dashed', colors='magenta')
    ax.vlines(lst_blk, dmin, dmax, linestyles='dashed', colors='cyan')
    ax.vlines(lst_0, dmin, dmax, linestyles='dashed', colors='black')
    ax.vlines(lst_1, dmin, dmax, linestyles='dashed', colors='blue')
    ax.vlines([mark_pos], dmin, dmax, linestyles='dashed', colors='red')


def edit_plot(ed_pos):
    global snd, mark_a, mark_s_a, clip_len
    #print(len(snd),ed_pos,clip_len)

    view_len = clip_len+gv.chunk_ed*2+1

    #scale = gv.chunk_win

    view_pos, mark_pos = value_check_off(ed_pos, -gv.chunk_ed)
    dat = snd[view_pos:view_pos+view_len]
    dat_win = snd[ed_pos:ed_pos+gv.chunk_win]

    # 布局
    #text = sg.Text("输入")
    #textinput = sg.InputText()
    ed_txt = sg.Text('标签')
    ed_txt_s = sg.Text('标签s')

    layout = [
        #[sg.Canvas(key='-Data-'),],
        [sg.Canvas(key='-Data Clip-'),sg.Canvas(key='-Data Win-'),],
        #[text, textinput],
        [[[sg.Button('M <<'), sg.Button('M >>'), sg.Text('    '), sg.Button('goto'), sg.InputText(size=(10,1)), sg.Text(' '), sg.Text('波形上下翻转'), sg.Button('invert'), sg.Text(' '), ed_txt, ed_txt_s, sg.Text('  wave size'), sg.Button('M-5'), sg.Button('M-4'), sg.Button('M-3'), sg.Button('M-2'), sg.Button('M-1'), sg.Button('M'), sg.Button('M+1'), sg.Button('M+2'), sg.Button('M+3'), sg.Text(' '), sg.Button('M unset'),]],[
        #sg.Button('m 0 >>'), sg.Button('m 1 >>'),
        [sg.Button('mark >>'), sg.Button('m 0 >>'), sg.Button('m 1 >>'), sg.Button('m b >>'), sg.Button('m u >>'), sg.Text(' '), sg.Button('>> 1'), sg.Button('>> 5'), sg.Button('>> 10'), sg.Button('>> 1/6'), sg.Button('>> 1/3'), sg.Button('>> 1/2'), sg.Button('>> 1bm'), sg.Button('>> 1b'), sg.Button('>> 4b'), sg.Button('>> 8b'), sg.Button('>> 1/10s'), sg.Button('>> 1/2s'), sg.Button('>> 1s'), sg.Button('>> 10s'), ],
        #sg.Button('m 0 <<'), sg.Button('m 1 <<'),
        [sg.Button('mark <<'), sg.Button('m 0 <<'), sg.Button('m 1 <<'), sg.Button('m b <<'), sg.Button('m u <<'), sg.Text(' '), sg.Button('<< 1'), sg.Button('<< 5'), sg.Button('<< 10'), sg.Button('<< 1/6'), sg.Button('<< 1/3'), sg.Button('<< 1/2'), sg.Button('<< 1bm'), sg.Button('<< 1b'), sg.Button('<< 4b'), sg.Button('<< 8b'), sg.Button('<< 1/10s'), sg.Button('<< 1/2s'), sg.Button('<< 1s'), sg.Button('<< 10s'), ],
        ],],
        [sg.Text(' '), sg.Button('unset'), sg.Text(' '), sg.Button('1'), sg.Button('0'), sg.Button('blank'), sg.Button('unk'), sg.Text(' '), sg.Button('blank 4b'), sg.Text(' '), 
        sg.Button('block 1/2 blank'), sg.Button('block 1/2 unk'), sg.Button('block 1/2 unset'), sg.Text(' '), sg.Button('save'), sg.Button('save and quit'), sg.Button('quit no save!'),],
    ]


    wnd = sg.Window('Embedding Matplotlib In PySimpleGUI', layout, finalize=True, location=(5,5), element_justification='center')
    #canvas_dat = wnd['-Data-'].TKCanvas
    canvas_clip = wnd['-Data Clip-'].TKCanvas
    canvas_win = wnd['-Data Win-'].TKCanvas

    dt = snd.dtype
    dmin, dmax = dtype_min(dt)
    #dmin, dmax = dtype_min_ed(dt)


    #figure_dat, ax_dat = plt.subplots(figsize=(15,2))
    figure_clip, ax_clip = plt.subplots(figsize=(10,5))
    figure_win, ax_win = plt.subplots(figsize=(5,5))

    #plt.close('all') # 有效，pyplot.py  _pylab_helpers.Gcf.destroy_all()
    ed_txt.update(value=dat_mark_text(ed_pos))
    ed_txt_s.update(value=dat_mark_s_text(ed_pos))

    #ax_dat.plot(snd)
    #draw_figure(canvas_dat, figure_dat)

    ax_clip.plot(dat)
    draw_mark(ax_clip, view_pos, mark_pos, view_len, gv.chunk_ed, dmin, dmax)
    draw_figure(canvas_clip, figure_clip)

    (w_min, w_max) = (-1.2,1.2)
    if dt in [np.int32, np.int16, np.int8, np.uint8]:
        (w_min, w_max) = win_zoom_int(dat_win,dmin,dmax)
    ax_win.set_ylim(w_min, w_max)
    #ax_win.set_ylim(dmin, dmax)
    ax_win.vlines([gv.chunk*2//3, gv.chunk, gv.chunk*5//3], w_min, w_max, linestyles='dashed', colors='silver')
    ax_win.vlines([gv.chunk//3, gv.chunk*4//3], w_min, w_max, linestyles='dashed', colors='red')
    if mark_s_a[ed_pos]!=gv.m_unset: ax_win.vlines( gv.chunk*((9+3-5+mark_s_a[ed_pos])*2-1)//(9*2), w_min, w_max, linestyles='dotted', colors='gold')
    #ax_win.vlines([gv.chunk//3, gv.chunk*2//3, gv.chunk, gv.chunk*4//3, gv.chunk*5//3, gv.chunk*2], w_min, w_max, linestyles='dashed', colors='silver')
    ax_win.plot(dat_win)
    draw_figure(canvas_win, figure_win)

    refresh_win = False

    #等待界面输入
    while True:
        event, values = wnd.read()
        #print(event, values)
        if event=='save and quit': break
        if event=='quit no save!': break

        cur_pos = ed_pos

        move_pos = 0
        if event=='<< 10s': move_pos = -sample_rate*10
        if event=='>> 10s': move_pos =  sample_rate*10
        if event=='<< 1s': move_pos = -sample_rate
        if event=='>> 1s': move_pos =  sample_rate
        if event=='<< 1/2s': move_pos = -sample_rate//2
        if event=='>> 1/2s': move_pos =  sample_rate//2
        if event=='<< 1/10s': move_pos = -sample_rate//10
        if event=='>> 1/10s': move_pos =  sample_rate//10
        if event=='<< 8b': move_pos = -gv.chunk*8
        if event=='>> 8b': move_pos =  gv.chunk*8
        if event=='<< 4b': move_pos = -gv.chunk*4
        if event=='>> 4b': move_pos =  gv.chunk*4
        if event=='<< 1bm': move_pos = -gv.chunk_min
        if event=='>> 1bm': move_pos =  gv.chunk_min
        if event=='<< 1b': move_pos = -gv.chunk
        if event=='>> 1b': move_pos =  gv.chunk
        if event=='<< 1/2': move_pos = -gv.chunk//2
        if event=='>> 1/2': move_pos =  gv.chunk//2
        if event=='<< 1/3': move_pos = -gv.chunk//3
        if event=='>> 1/3': move_pos =  gv.chunk//3
        if event=='<< 1/6': move_pos = -gv.chunk//6
        if event=='>> 1/6': move_pos =  gv.chunk//6
        if event=='<< 10': move_pos = -10
        if event=='>> 10': move_pos =  10
        if event=='<< 5': move_pos = -5
        if event=='>> 5': move_pos =  5
        if event=='<< 1': move_pos = -1
        if event=='>> 1': move_pos =  1

        if event=='goto':
            v = values[0].strip()
            if v.isdigit():
                i = int(v)
                if i>=0 and i<len(snd):
                    move_pos = i - ed_pos
                    #print(move_pos)

        # 查找下一个标记位置
        if event=='M >>':
            i = 1
            while ed_pos+i<len(snd):
                if mark_s_a[ed_pos+i]!=gv.m_unset:
                    move_pos=i
                    #refresh_win = True
                    break
                i+=1
        # 查找上一个标记位置
        if event=='M <<':
            i = -1
            while ed_pos+i>=0:
                if mark_s_a[ed_pos+i]!=gv.m_unset:
                    move_pos=i
                    #refresh_win = True
                    break
                i-=1

        # 查找下一个标记位置
        if event=='mark >>':
            i = 1
            while ed_pos+i<len(snd):
                if mark_a[ed_pos+i]!=gv.m_unset:
                    move_pos=i
                    #refresh_win = True
                    break
                i+=1
        # 查找上一个标记位置
        if event=='mark <<':
            i = -1
            while ed_pos+i>=0:
                if mark_a[ed_pos+i]!=gv.m_unset:
                    move_pos=i
                    #refresh_win = True
                    break
                i-=1

        # 查找下一个标记位置
        mm = gv.m_unset
        if event=='m 0 >>': mm = gv.m_0
        if event=='m 1 >>': mm = gv.m_1
        if event=='m b >>': mm = gv.m_blk
        if event=='m u >>': mm = gv.m_unk
        if mm!=gv.m_unset:
            i = 1
            while ed_pos+i<len(snd):
                if mark_a[ed_pos+i]==mm:
                    move_pos=i
                    #refresh_win = True
                    break
                i+=1

        # 查找上一个标记位置
        mm = gv.m_unset
        if event=='m 0 <<': mm = gv.m_0
        if event=='m 1 <<': mm = gv.m_1
        if event=='m b <<': mm = gv.m_blk
        if event=='m u <<': mm = gv.m_unk
        if mm!=gv.m_unset:
            i = -1
            while ed_pos+i>=0:
                if mark_a[ed_pos+i]==mm:
                    move_pos=i
                    #refresh_win = True
                    break
                i-=1

        if move_pos!=0:
            ed_pos = value_between(ed_pos+move_pos, gv.chunk_ed, len(snd)-clip_len-gv.chunk_ed)
            if cur_pos!=ed_pos:
                view_pos, mark_pos = value_check_off(ed_pos, -gv.chunk_ed)
                dat = snd[view_pos:view_pos+view_len]
                dat_win = snd[ed_pos:ed_pos+gv.chunk_win]
                refresh_win = True

        if event=='M unset':
            dat_mark_s(ed_pos, gv.m_unset)
            refresh_win = True

        if event=='M-5':
            dat_mark_s(ed_pos, 0)
            refresh_win = True
        if event=='M-4':
            dat_mark_s(ed_pos, 1)
            refresh_win = True

        if event=='M-3':
            dat_mark_s(ed_pos, 2)
            refresh_win = True
        if event=='M-2':
            dat_mark_s(ed_pos, 3)
            refresh_win = True
        if event=='M-1':
            dat_mark_s(ed_pos, 4)
            refresh_win = True

        if event=='M':
            dat_mark_s(ed_pos, 5)
            refresh_win = True

        if event=='M+1':
            dat_mark_s(ed_pos, 6)
            refresh_win = True
        if event=='M+2':
            dat_mark_s(ed_pos, 7)
            refresh_win = True
        if event=='M+3':
            dat_mark_s(ed_pos, 8)
            refresh_win = True


        if event=='unset':
            dat_mark(ed_pos, gv.m_unset)
            refresh_win = True

        if event=='0':
            dat_mark(ed_pos, gv.m_0)
            refresh_win = True

        if event=='1':
            dat_mark(ed_pos, gv.m_1)
            refresh_win = True

        if event=='blank':
            dat_mark(ed_pos, gv.m_blk)
            refresh_win = True

        if event=='unk':
            dat_mark(ed_pos, gv.m_unk)
            refresh_win = True

        if event=='blank 4b':
            dat_mark(ed_pos, gv.m_blk, gv.m_blk, gv.m_blk, gv.m_blk)
            refresh_win = True

        if event=='block 1/2 unk':
            blk_mark(ed_pos, gv.m_unk, gv.chunk*3//5)
            refresh_win = True

        if event=='block 1/2 blank':
            blk_mark(ed_pos, gv.m_blk, gv.chunk*3//5)
            refresh_win = True

        if event=='block 1/2 unset':
            blk_mark(ed_pos, gv.m_unset, gv.chunk*3//5)
            refresh_win = True

        if event=='invert':
            snd = np_data_invert(snd)
            break

        if event=='save':
            dat_mark_save()

        if event in  (None, 'Exit'):
            break

        if refresh_win:
            refresh_win = False
            ed_txt.update(value=dat_mark_text(ed_pos))
            ed_txt_s.update(value=dat_mark_s_text(ed_pos))
            #plt.delaxes(ax) # 有效，删除 ax, 无法后续使用
            clearplot(canvas_clip)
            ax_clip.clear()
            ax_clip.plot(dat)

            clearplot(canvas_win)
            ax_win.clear()
            (w_min, w_max) = (-1.2,1.2)
            if dt in [np.int32, np.int16, np.int8, np.uint8]:
                (w_min, w_max) = win_zoom_int(dat_win,dmin,dmax)
            ax_win.set_ylim(w_min, w_max)
            #ax_win.set_ylim(dmin, dmax)
            ax_win.vlines([gv.chunk*2//3, gv.chunk, gv.chunk*5//3], w_min, w_max, linestyles='dashed', colors='silver')
            ax_win.vlines([gv.chunk//3, gv.chunk*4//3], w_min, w_max, linestyles='dashed', colors='red')
            if mark_s_a[ed_pos]!=gv.m_unset: ax_win.vlines( gv.chunk*((9+3-5+mark_s_a[ed_pos])*2-1)//(9*2), w_min, w_max, linestyles='dotted', colors='gold')
            #ax_win.vlines([gv.chunk//3, gv.chunk*2//3, gv.chunk, gv.chunk*4//3, gv.chunk*5//3, gv.chunk*2], w_min, w_max, linestyles='dashed', colors='silver')
            ax_win.plot(dat_win)

            draw_mark(ax_clip, view_pos, mark_pos, view_len, gv.chunk_ed, dmin, dmax)
            draw_figure(canvas_clip, figure_clip)
            draw_figure(canvas_win, figure_win)

    wnd.close()

    return event, values



pathsep=os.path.sep
in_filepath = "./train_data" #数据路径
idx_filepath = "./train_data" #索引路径
out_filepath = "./vz_data" #输出路径
#filename_lst = os.listdir(in_filepath) #得到文件夹下的所有文件名称

#for base_name in filename_lst:
#base_name = 'LADDER.WAV'

dat_fn = ''
idx_fn = ''
idx_s_fn = ''

def edit_data(base_name):
    global snd, mark_s_a, mark_a, sample_rate, clip_len, dat_fn, idx_fn, idx_s_fn
    dat_fn = in_filepath+pathsep+base_name
    idx_fn = ''
    file_name, fn_ext = os.path.splitext(base_name)
    if not os.path.isfile(dat_fn): return
    if fn_ext.lower()!=".wav": return
    idx_fn = idx_filepath+pathsep+file_name+".jsonl"
    idx_s_fn = idx_filepath+pathsep+file_name+".s.jsonl"
    #print(dat_fn, idx_fn, idx_s_fn)

    sig, sample_rate, n_channels, n_frames = wavfile_read(dat_fn)
    #sample_rate, sig = wavfile.read(in_filepath+pathsep+base_name)
    print("采样率: {}  数据量: {}  数据格式: {} 时间: {} 秒".format(sample_rate, sig.shape, sig.dtype, n_frames//sample_rate))
    # print(sig)
    # nchannels:声道数 sampwidth:量化位数（byte）framerate:采样频率 nframes:采样点数
    # 采样频率:每秒钟采集多少个信号样本

    '''
    if sig.dtype == np.uint8:
        print("PCM8位整数")
    if sig.dtype == np.int16:
        print("PCM16位整数")
    if sig.dtype == np.int32:
        print("PCM32位整数")
    if sig.dtype == np.float32:
        print("PCM32位浮点")
    '''

    #声道选择
    # 不支持多音轨
    # 只处理第一个声道
    if n_channels>1:
        snd = sig[:,0]
    else:
        snd = sig


    # 读标记文件
    mark_a = [ gv.m_unset for _ in range(len(snd))]

    # 载入已经标注过的点
    if os.path.exists(idx_fn):
        with jsonlines.open(idx_fn) as reader:
            for obj in reader:
                #print(obj)
                for k,v in obj.items():
                    #print(k, v)
                    #dat_mark(int(k),v)
                    mark_a[int(k)]= v


    # 读标记文件
    mark_s_a = [ gv.m_unset for _ in range(len(snd))]

    # 载入已经标注过的点
    if os.path.exists(idx_s_fn):
        with jsonlines.open(idx_s_fn) as reader:
            for obj in reader:
                #print(obj)
                for k,v in obj.items():
                    #print(k, v)
                    #dat_mark_s(int(k),v)
                    mark_s_a[int(k)]= v

    #函数fft对声音进行快速傅立叶变换（FFT），得到声音的频谱。
    #n = len(snd)
    #p = fft(snd)         #执行傅立叶变换

    wav_chunk(sample_rate)

    clip_len = gv.chunk_ed*8

    off=0


    #标准化，使数据在-1.0，1.0之间
    data = wav_dtype_to_float32(snd)

    # TH 阈值 - Threshold
    # 低于TH，认为是静音
    #TH = 0.1
    #TH = 0.05
    TH = 0.03

    #找到有声音的位置
    rms = np_rms(data, clip_len)
    off=0
    cnt = len(rms)
    while off<cnt:
        if rms[off]>TH: break
        off=off+1

    if off>1: off=off-1

    off = off*clip_len

    while True:
        #print(off, gv.chunk)
        event, values = edit_plot(off)
        #print(event, values)
        if event=='save and quit': break
        if event=='quit no save!': break

    #print(mark_a)

    if event=='save and quit':
        cnt = dat_mark_save()
        cnt = dat_mark_s_save()
        print(cnt)

    #with open(idx_fn,"w", encoding='utf-8') as f: ## 设置'utf-8'编码
    #    f.write(json.dumps(mark_d, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('fn', type=str, help='filename')
    args = parser.parse_args()
    #print(args)
    edit_data(args.fn)
