import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg,NavigationToolbar2Tk

'''
def plot_data(data):
    plt.figure()
    plt.plot(data)
    # 显示曲线
    plt.show()
'''

def plot_data(data):
    figure, ax = plt.subplots()
    plt.plot(data)
    # 显示曲线
    plt.show()

def plot_data_win(data, w_min, w_max):
    figure, ax = plt.subplots()
    ax.set_ylim(w_min, w_max)
    plt.plot(data)
    # 显示曲线
    plt.show()

# plot the wave
def plot_wave(data, norm=False):
    nframes = data.shape[0]
    #time = np.arange(0,nframes)*(1.0 / framerate)
    time = np.arange(0,nframes)
    #waveData = np.fromstring(data,dtype=np.int16) #将字符串转化为int
    if norm:
        waveData = data*1.0/(max(abs(data))) #wave幅值归一化
    else:
        waveData = data
    plt.plot(time,waveData)
    plt.xlabel("Time(s)")
    plt.ylabel("Amplitude")
    plt.title("Single channel wavedata")
    plt.grid(True) #标尺，True：有，False:无。
    # 显示曲线
    plt.show()


#https://zhuanlan.zhihu.com/p/521509335
#PySimpleGUI调用Matplotlib输出图像

#https://cloud.tencent.com/developer/ask/sof/914217

def clearplot(wnd):
    for widget in wnd.winfo_children():
        if 'Canvas' in str(type(widget)):
            widget.destroy()


# 画在canvas上，包括工具条
def draw_toolbar_figure(canvas, canvas_toolbar, figure):
	figure_canvas_agg = FigureCanvasTkAgg(figure, canvas)
	figure_canvas_agg.draw()
	toolbar = NavigationToolbar2Tk(figure_canvas_agg, canvas_toolbar)
	toolbar.update()

	figure_canvas_agg.get_tk_widget().pack(side='top', fill='both', expand=1)
	#return figure_canvas_agg


def draw_figure(canvas, figure):
	figure_canvas_agg = FigureCanvasTkAgg(figure, canvas)
	figure_canvas_agg.draw()

	figure_canvas_agg.get_tk_widget().pack(side='top', fill='both', expand=1)
	#return figure_canvas_agg

