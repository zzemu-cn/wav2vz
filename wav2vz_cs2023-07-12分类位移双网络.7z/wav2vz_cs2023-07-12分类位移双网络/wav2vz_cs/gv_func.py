import gv

def wav_chunk(sample_rate):
    #chunk = 79 # 48K 79.92
    gv.chunk_min = sample_rate*gv.chunk_time_min // 1000000
    gv.chunk_max = sample_rate*gv.chunk_time_max // 1000000
    gv.chunk = sample_rate*gv.chunk_time // 1000000
    gv.chunk_ed = sample_rate*gv.chunk_time_ed // 1000000
    gv.chunk_win = sample_rate*gv.chunk_time * 5 // (1000000*3)

    gv.chunk_init = sample_rate*gv.chunk_time_init // 1000000


    gv.chunk_wide = sample_rate*gv.chunk_time * gv.chunk_rate // 100 // 1000000
    
    gv.chunk_step_min = sample_rate*gv.chunk_time_min * 95 // 100 // 1000000
    gv.chunk_step = sample_rate*gv.chunk_time * 95 // 100 // 1000000

    gv.chunk_skip = sample_rate*1000*3 // 1000000

    #gv.chunk_skip_min = sample_rate*800*3 // 1000000
    gv.chunk_skip_min = sample_rate*980*3 // 1000000
    #gv.chunk_skip_min = sample_rate*1000*3 // 1000000

    # 用于检查识别后，一个字节占用的数据长度, 误差 2%
    #gv.chunk_byte = sample_rate*gv.chunk_time * 8 * 1020 // (1000000 * 1000)

    return gv.chunk
