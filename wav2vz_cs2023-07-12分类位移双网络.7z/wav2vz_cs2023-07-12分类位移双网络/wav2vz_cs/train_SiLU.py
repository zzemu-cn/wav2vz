'''
# Brian Murray, brian@proximity.com.au
# 参考了 VZREAD.C

一、录音磁带的格式
波形图见
数据磁带机.png
LASER310_cas_0xAA_Figure.png

读入的字节依次为：
同步和前导：128个 或 (LASER310)255个 0x80 5个 0xFE
程序类型：1字节 TYPE
程序文件名：17字节 FILENAME
程序开始： 2字节 START
程序结束：2字节 END
程序数据：
求和校验值：
结尾：0x00 1个字节 或 (LASER310)20个, 没有该字节不影响读取

录音末尾是求和校验值
计算方法是 0xFF00 或 0x0000 、文件开始（高低字节）、文件结尾（高低字节）、数据，求和后取低16位。
LASER310 是 0x0000

在读入文件名后，约有0.003秒的静音。这段时间应该是留给程序显示文件名用的。
长度约 555us x 5.5

二、vz 文件格式
VZF_MAGIC : 4个字节 0x20 0x20 0x00 0x00 或者是 0x56 0x5A 0x46 0x30
vzf_filename : 17个字节 最后一个字节必须为零，末尾不足的字符用空格0x20代替
vzf_type : 1个字节 同磁带
vzf_startaddr : 2个字节 程序开始地址
之后是数据
后是数据

# VZREAD.C中的算法是采样最小值到最大值的距离，来判断波长。
# 问题是方波的最小值和最大值的位置不稳定，特别是高精度采样时。

'''

# 用 list 或 dict 存贮标志位置和值，会带来复杂的数据操作。
# 直接用于snd 一一对应的list来存储标志
# mark_a = [ gv.m_unset for _ in range(len(snd))]

import matplotlib.pyplot as plt
#import matplotlib.image as mpimg
import numpy as np
import random
import os
#import struct

from collections import Counter

#from pylab import *
from scipy.io import wavfile
from scipy.fftpack import fft
#import scipy.ndimage.filters as filt
from scipy import ndimage
from scipy.interpolate import interp1d
#import scipy.ndimage.uniform_filter as filt

#import tkinter as tk

import torch
from torch import nn

from tsc_SiLU import *
from wav_tools import *

import gv
from gv_func import *

#import PySimpleGUI as sg

#jsonlines-3.1.0
import jsonlines
#import argparse

#verbose=False
verbose=True

os.environ['KMP_DUPLICATE_LIB_OK'] ='TRUE'

device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
print(f"Using {device} device")

random.seed()

model_dict_fn = 'tsc_SiLU.pth'

batch_size=32
#batch_size=16
#batch_size=1

hidden_dim = 128
input_dim = 200
output_dim = 4

np_dtype = 'float32'


#input_dim, hidden_dim, output_dim
model = TimeSeriesClassifier(input_dim,hidden_dim,output_dim).to(device)

#model.load_state_dict(torch.load(model_dict_fn))


train_data = []

mark_a = []

snd=None


#数据长度从n0拉伸到n1
def input_data_interp(y, n0, n1):
    x=np.arange(n0)
    #长度不足n0则填充
    y=np.pad(y, n0-len(y), 'edge')
    #拉伸到 data_len
    f=interp1d(x, y, kind='linear')
    xx = np.linspace(0, n0-1, num=n1)
    return f(xx)

def dat_mark(k,*args):
    global mark_a

    for v in args:
        mark_a[k] = v
        k = k+gv.chunk

def mark_text(m):
    s='unset'
    if m==gv.m_unk: s='unk'
    if m==gv.m_blk: s='blk'
    if m==gv.m_0: s='0'
    if m==gv.m_1: s='1'
    return s

def dat_mark_text(pos):
    global mark_a
    mark = mark_a[pos]
    s=mark_text(mark)
    return "pos %d : %s"%(pos,s)



#fig = plt.figure()
figure, ax = plt.subplots()

pathsep=os.path.sep
in_filepath = "./train_data" #数据路径
idx_filepath = "./train_data" #标注路径
#out_filepath = "./vz_data" #输出路径
#filename_lst = os.listdir(in_filepath) #得到文件夹下的所有文件名称

def gen_train_data():
    global snd, mark_a
    global train_data
    filename_lst = os.listdir(in_filepath) #得到文件夹下的所有文件名称

    for base_name in filename_lst:
        fn = in_filepath+pathsep+base_name
        data_idx_fn = ''
        file_name, fn_ext = os.path.splitext(base_name)
        if not os.path.isfile(fn): continue
        if fn_ext.lower()!=".wav": continue
        data_idx_fn = idx_filepath+pathsep+file_name+".jsonl"
        if not os.path.isfile(data_idx_fn): continue

        print(fn)
        sig, sample_rate, n_channels, n_frames = wavfile_read(fn)
        #sample_rate, sig = wavfile.read(in_filepath+pathsep+base_name)
        print("采样率: {}  数据量: {}  数据格式: {} 时间: {} 秒".format(sample_rate, sig.shape, sig.dtype, n_frames//sample_rate))
        # print(sig)
        # nchannels:声道数 sampwidth:量化位数（byte）framerate:采样频率 nframes:采样点数
        # 采样频率:每秒钟采集多少个信号样本

        '''
        if sig.dtype == np.uint8:
            print("PCM8位整数")
        if sig.dtype == np.int16:
            print("PCM16位整数")
        if sig.dtype == np.int32:
            print("PCM32位整数")
        if sig.dtype == np.float32:
            print("PCM32位浮点")
        '''

        #声道选择
        # 不支持多音轨
        # 只处理第一个声道
        if n_channels>1:
            snd = sig[:,0]
        else:
            snd = sig

        wav_chunk(sample_rate)

        #标准化，使数据在-1.0，1.0之间
        data = wav_dtype_to_float32(snd)

        #print(data.dtype)

        cnt = 0
        # 读标记文件
        if os.path.exists(data_idx_fn):
            with jsonlines.open(data_idx_fn) as reader:
                for obj in reader:
                    #print(obj)
                    for k,v in obj.items():
                        k = int(k)
                        #print(mark_text(v))
                        #plt_data(snd[k:k+gv.chunk_wide])
                        #plt.plot(snd[k:k+gv.chunk_wide])
                        #plt.show()
                        #print(k, v)
                        #dat = data[k:k+gv.chunk_wide]
                        #dat = input_data_interp(dat,gv.chunk_wide,input_dim)
                        dat = data[k:k+gv.chunk_win]
                        dat = input_data_interp(dat,gv.chunk_win,input_dim)
                        train_data.append([dat,v])
                        #上下对称的数据
                        #train_data.append([-dat,v])
                        cnt += 1
                        #print(k, len(dat), v)

        print("标注数据量",cnt)

    None

loss_fn = nn.CrossEntropyLoss(reduction='mean')
optimizer = torch.optim.SGD(model.parameters(), lr=1e-3)

def train():
    global train_data, batch_size
    data_size = len(train_data)

    model.train()

    for batch in range((data_size+batch_size-1)//batch_size):
        #print(batch)

        dat = train_data[batch*batch_size:(batch+1)*batch_size]
        # 不足部分随机选取
        while len(dat)<batch_size:
            dat.append(random.choice(train_data))
        #print(len(dat))
        X = [[d] for d,v in dat]
        y = [v for d,v in dat]
        #print(X,y)

        X = np.array(X,dtype=np_dtype)
        y = np.array(y,dtype=np.int64)
        #print(X.shape,y.shape)
        X = torch.tensor(X)
        y = torch.tensor(y)

        X = X.to(device)
        y = y.to(device)

        # Compute prediction error
        #print(X.dtype,y.dtype)
        pred = model(X)
        #print(pred.shape,y.shape)
        #[8,4]
        #print(pred,y)

        loss = loss_fn(pred, y)

        # Backpropagation
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        #print(loss)

    #for batch, (X, y) in enumerate(train_data_loader):
    #for batch, (X, y) in enumerate(train_data_loader):
    #model.train()
    #for batch, (X, y) in enumerate(dataloader):

    None


def test_step(bat_size, pos=-1):
    global train_data
    data_size = len(train_data)
    #print(data_size)

    dat = []
    n = bat_size

    # 随机选取 pos==-1
    if pos>=0 and pos<data_size:
        if pos+n > data_size:
            n = data_size - pos
        dat = train_data[pos:pos+n]

    # 随机选取，不齐 bat_size 个数据
    while len(dat)<bat_size:
        dat.append(random.choice(train_data))


    X = [[d] for d,v in dat]
    y = [v for d,v in dat]

    X = np.array(X,dtype=np_dtype)
    y = np.array(y,dtype=np.int64)
    #print(X.shape,y.shape)
    X = torch.tensor(X)
    y = torch.tensor(y)

    X = X.to(device)
    y = y.to(device)

    model.eval()

    test_loss, correct = 0, 0
    pred = model(X)
    test_loss += loss_fn(pred, y).item()
    correct += (pred.argmax(1) == y).type(torch.float).sum().item()
    #test_loss /= num_batches
    #correct /= bat_size
    #print(f"Test Error: \n Accuracy: {(100*correct):>0.1f}%, Avg loss: {test_loss:>8f}")
    #print(f"Test Error: \n Accuracy: {bat_size}:{correct}, Avg loss: {test_loss:>8f}")
    #print(y,"y")
    #print(pred.argmax(1),"pred")

    return (test_loss, correct)


def test():
    global train_data
    data_size = len(train_data)
    #print(data_size)

    #bat_size=32
    #bat_size=128
    bat_size=256

    test_loss, correct = 0, 0

    # 随机选取
    #test_cnt = bat_size
    #(test_loss, correct) = test_step(bat_size, -1)

    # 对所有样本进行测试
    test_cnt = 0
    for pos in range(0,data_size,bat_size):
        (test_loss_step, correct_step) = test_step(bat_size, pos)
        test_cnt += bat_size
        test_loss += test_loss_step
        correct += correct_step


    #correct /= test_cnt
    #print(f"Test Error: \n Accuracy: {(100*correct):>0.1f}%, Avg loss: {test_loss:>8f}")
    print(f"Test Error: \n Accuracy: {test_cnt}:{correct}, Avg loss: {test_loss:>8f}")

    None


def train_loop():
    #data_size = len(train_data)
    #print(data_size)

    epochs = 1000
    for t in range(epochs):
        train()
    test()

if __name__ == "__main__":
    gen_train_data()

    print("用于训练的标注数据量", len(train_data))

    # 统计 train_data 中元素出现的频率
    vlst = []
    for (d,v) in train_data:
        vlst.append(v)
    print(Counter(vlst))

    # 打乱顺序
    random.shuffle(train_data)

    if os.path.isfile(model_dict_fn):
        model.load_state_dict(torch.load(model_dict_fn))

    for i in range(5000):
        train_loop()
        torch.save(model.state_dict(), model_dict_fn)

    #parser = argparse.ArgumentParser()
    #parser.add_argument('fn', type=str, help='filename')
    #args = parser.parse_args()
    #print(args)
    #train_data(args.fn)
