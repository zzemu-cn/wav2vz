from tsc import *

device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
print(f"Using {device} device")

hidden_dim= 128
input_dim = 200
output_dim = 4

#input_dim, hidden_dim, output_dim
model = TimeSeriesClassifier(input_dim,hidden_dim,output_dim).to(device)

model.train()

#torch.save(model.state_dict(), "tsc_init.pth")
torch.save(model.state_dict(), "tsc.pth")
