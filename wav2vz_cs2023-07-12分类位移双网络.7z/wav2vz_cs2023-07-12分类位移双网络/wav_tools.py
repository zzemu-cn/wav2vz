from scipy.io import wavfile
import numpy as np

# 读取音频文件
def wavfile_read(filename):
    sample_rate, data = wavfile.read(filename)
    n_frames = data.shape[0];
    n_channels = data.shape[1] if len(data.shape)==2 else 1
    return data, sample_rate, n_channels, n_frames

def is_int(dtype):
    return True if dtype == np.uint8 or dtype == np.int16 or dtype==np.int32 else False

def value_between(v,start,stop):
    if v<start: return start
    if v>=stop: return stop-1
    return v

def value_check_off(v,off):
    d = off if v+off>=0 else 0
    return v+d, -d


'''
-1.0        +1.0        float32
-2147483648 +2147483647 int32       32-bit integer
-2147483648 +2147483392 int32       24-bit integer
-32768      +32767      int16
0           255         uint8
'''

def dtype_min(dt):
    dmin=-1.0
    dmax=1.0

    if dt == np.float32:
        dmin=-1.0
        dmax=1.0

    if dt == np.int32:
        dmin=-2147483648
        dmax=2147483647

    if dt == np.int16:
        dmin=-32768
        dmax=32767

    if dt == np.uint8:
        dmin=0
        dmax=255

    if dt == np.uint16:
        dmin=0
        dmax=65535

    if dt == np.uint32:
        dmin=0
        dmax=4294967295

    return dmin,dmax


# 为 dat 找个合适的缩放比例
# 10% 20% 40% 60% 80%
def win_zoom_int(dat,dmin,dmax):
    dat_min = min(dat)
    dat_max = max(dat)
    w_min = dmin
    w_max = dmax

    for i in [1,2,4,6,8]:
        n_min = dmin*i//10
        n_max = dmax*i//10
        if dat_min<n_min or dat_max>n_max: continue
        w_min = n_min
        w_max = n_max
        break

    return (w_min,w_max)


#标准化，使数据在-1.0，1.0之间
def wav_dtype_to_float32(data):
    dt = data.dtype
    dmin, dmax = dtype_min(dt)

    #print(dmin, dmax)

    #转换数据类型
    data = data.astype(np.float32) 

    #标准化，使数据在-1.0，1.0之间
    if dt in [np.int32, np.int16, np.uint8]:
        data = (data-dmin)/(dmax-dmin)*2-1

    return data

def np_data_invert(data):
    dt = data.dtype
    dmin, dmax = dtype_min(dt)
    if dt in [np.int32, np.int16, np.int8]:
        return np.invert(data)
    if dt in [np.uint32, np.uint16, np.uint8]:
        return dmax-data
    return -data
       

#求所有窗口的差值中的最大值
def np_max_diff(data, chunk):
    n_frames = data.shape[0]
    diff = []
    for i in range(0, n_frames, chunk):
        y = data[i:i+chunk]
        diff.append(y.max()-y.min())

    return max(diff)

# 计算音频的均方根（RMS）值
def np_rms(data, chunk):
    n_frames = data.shape[0]
    rms = []
    for i in range(0, n_frames, chunk):
        y = data[i:i+chunk]
        rms.append(np.sqrt(np.mean(y ** 2)))
    return rms


# TH 阈值 - Threshold
# 低于TH，认为是静音
#TH = 0.05
#TH = 0.1
def wav_split(data, TH, chunk, chunk_min=1):
    rms = np_rms(data, chunk)

    cnt=len(rms)
    print(cnt)

    split_a = []

    off=0
    start_clip=False
    while off<cnt:
        if start_clip:
            if rms[off]<=TH:
                start_clip=False
                end_pos=off
                if end_pos-start_pos>chunk_min:
                    split_a.append((start_pos, end_pos))
        else:
            if rms[off]>TH:
                start_clip=True
                start_pos=off

        off=off+1

    if start_clip:
        if end_pos-start_pos>chunk_min:
            split_a.append((start_pos, end_pos))

    return split_a

