
# 磁带数据 1 bit 占用的时间
# Laser310 Demo Tape B.1.wav 波形长度多种，400 到 600, 暂时选取 395 作为最小波形长度
# 文件 48-B.11.wav 波形超过600。
# 文件 CHECKER.1.wav 6852-6810=42 42000000/22050/3=634 或 620
# 文件 CHECKER.2.wav 9400-9353=47 47000000/22050/3=710  6249-6201=48 48000000/22050/3=725

chunk_time_min = 395*3

# 正常窗口
#chunk_time_max = 600*3

# 大窗口
chunk_time_max = 725*3

chunk_time = 555*3

chunk_time_ed = 555*3
#chunk_time_ed = 725*3

#chunk_time_init = 395*3
chunk_time_init = 500*3
# 跳到下一个位的百分比
#chunk_time_rate = 98
#chunk_time_rate = 97
#chunk_time_rate = 96
#chunk_time_rate = 95
chunk_time_rate = 92

# 设置 90 以下会出现跳不过 2/3 位的情况，造成误识别
#chunk_time_rate = 90


# 个别文件 48-B.11.wav 波形超过600。在数据窗口中容不下，设为9%可能更合适。例如：11319-11232=87
# 数据窗口适当扩充 9%，这样可以看到完整的波形

# 正常窗口
# 555 * 1.09 = 605
chunk_rate = 109

# 大窗口
# 555 * 1.34 = 743
#chunk_rate = 134

chunk_byte_max_rate = 105

#chunk = 79 # 48K 79.92
#chunk = sample_rate*555*3 // 1000000
chunk_min = 0
chunk_max = 0
chunk = 0
chunk_win = 0
chunk_ed = 0


chunk_init = 0

#chunk_wide = sample_rate*555*3 * chunk_rate // 100 // 1000000
chunk_wide = 0

# 下一个搜索的数据位移
#chunk_step = sample_rate*555*3 * 95 // 100 // 1000000
chunk_step_min = 0
chunk_step = 0

# LASER310数据磁带，读入文件名后，跳过空白
#chunk_skip = sample_rate*1000*3 // 1000000
chunk_skip = 0

# 用于检查识别后，一个字节占用的数据长度, 误差 2%
# 已经使用附近byte长度平均值来判断
#chunk_byte = sample_rate*555*3 * 8 * 1002 // (1000000 * 1000)
#chunk_byte = 0

# 波形标记 
m_unset = -1
m_unk = 0
m_blk = 1
m_0 = 2
m_1 = 3

# 分割点
md_unset = -1
md_unk = 0
md_blk = 1
md_0 = 2
md_1 = 3
md_mid = 4


