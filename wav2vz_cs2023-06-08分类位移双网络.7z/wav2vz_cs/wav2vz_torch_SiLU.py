'''
# Brian Murray, brian@proximity.com.au
# 参考了 VZREAD.C

一、录音磁带的格式
波形图见
数据磁带机.png
LASER310_cas_0xAA_Figure.png

读入的字节依次为：
同步和前导：128个 或 (LASER310)255个 0x80 5个 0xFE
程序类型：1字节 TYPE
程序文件名：17字节 FILENAME
程序开始： 2字节 START
程序结束：2字节 END
程序数据：
求和校验值：
结尾：0x00 1个字节 或 (LASER310)20个, 没有该字节不影响读取

录音末尾是求和校验值
计算方法是 0xFF00 或 0x0000 、文件开始（高低字节）、文件结尾（高低字节）、数据，求和后取低16位。
LASER310 是 0x0000

在读入文件名后，约有0.003秒的静音。这段时间应该是留给程序显示文件名用的。
长度约 555us x 5.5

二、vz 文件格式
VZF_MAGIC : 4个字节 0x20 0x20 0x00 0x00 或者是 0x56 0x5A 0x46 0x30
vzf_filename : 17个字节 最后一个字节必须为零，末尾不足的字符用空格0x20代替
vzf_type : 1个字节 同磁带
vzf_startaddr : 2个字节 程序开始地址
之后是数据
后是数据

# VZREAD.C中的算法是采样最小值到最大值的距离，来判断波长。
# 问题是方波的最小值和最大值的位置不稳定，特别是高精度采样时。

'''

# 用 list 或 dict 存贮标志位置和值，会带来复杂的数据操作。
# 直接用于snd 一一对应的list来存储标志
# mark_a = [ gv.m_unset for _ in range(len(snd))]

import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
import random
import os
#import struct

#from pylab import *
from scipy.io import wavfile
from scipy.fftpack import fft
#import scipy.ndimage.filters as filt
from scipy import ndimage
from scipy.interpolate import interp1d
#import scipy.ndimage.uniform_filter as filt

#import tkinter as tk

import torch
from torch import nn

from tsc_SiLU import *
from tsc_s_SiLU import *
from wav_tools import *

import gv
from gv_func import *

#import PySimpleGUI as sg

#jsonlines-3.1.0
import jsonlines
#import argparse


#verbose=False
verbose=True

os.environ['KMP_DUPLICATE_LIB_OK'] ='TRUE'

device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
print(f"Using {device} device")

model_dict_fn = 'tsc_SiLU.pth'
model_s_dict_fn = 'tsc_s_SiLU.pth'

#batch_size=128
#batch_size=64
batch_size=32
#batch_size=16
#batch_size=1

hidden_dim = 128
input_dim = 200
output_dim = 4

np_dtype = 'float32'


#input_dim, hidden_dim, output_dim
model = TimeSeriesClassifier(input_dim,hidden_dim,output_dim).to(device)
model_s = TimeSeriesClassifierSize(input_dim,hidden_dim,output_dim).to(device)

#model.load_state_dict(torch.load(model_dict_fn))

#model.eval()
#model.train()

# 标志缓存，可以一次计算多个标志
mark_a = []
mark_s_a = []

bit_a = [0 for _ in range(8)]
bit_s_a = [0 for _ in range(8)]

# 下一个检测点
chunk_cur = 0

# 用于识别后，byte 数据量的检测
chunk_avg_cur = 0

snd=None

def mark_s_flag(m):
    s='?'
    if m==0: s='B'
    if m==1: s='<'
    if m==2: s=' '
    if m==3: s='>'
    if m==4: s='E'
    return s

def mark_s_n(m):
    # gv.chunk - gv.chunk*(100-gv.chunk_time_rate)*6//600
    n = gv.chunk*gv.chunk_time_rate//100
    if m == 0: n = gv.chunk*(400-(100-gv.chunk_time_rate)*6)//600
    if m == 1: n = gv.chunk*(500-(100-gv.chunk_time_rate)*6)//600
    if m == 2: n = gv.chunk*(600-(100-gv.chunk_time_rate)*6)//600
    if m == 3: n = gv.chunk*(700-(100-gv.chunk_time_rate)*6)//600
    if m == 4: n = gv.chunk*(800-(100-gv.chunk_time_rate)*6)//600
    return n

#数据长度从n0拉伸到n1
def input_data_interp(y, n0, n1):
    x=np.arange(n0)
    #长度不足n0则填充
    y=np.pad(y, n0-len(y), 'edge')
    #拉伸到 data_len
    f=interp1d(x, y, kind='linear')
    xx = np.linspace(0, n0-1, num=n1)
    return f(xx)


import matplotlib.pyplot as plt

#figure, ax = plt.subplots()

def mark_flag(m):
    s='?'
    if m==gv.m_unk: s='u'
    if m==gv.m_blk: s='b'
    if m==gv.m_0: s='0'
    if m==gv.m_1: s='1'
    return s

pathsep=os.path.sep
in_filepath = "../wav_files_split" #数据路径
idx_filepath = "./train_data" #标注路径
out_filepath = "../vz_files" #输出路径
#filename_lst = os.listdir(in_filepath) #得到文件夹下的所有文件名称

#用来给识别打补丁。可以在加载时判断文件名，给出特定的ID。
file_id = 0

# DEMONSTRATION.28.inv.wav
#file_id = 1


def recog_data(data, off_start):
    global chunk_cur, chunk_avg_cur, mark_a, mark_s_a
    data_len = len(data)

    byte_pos_start=0
    buf = []
    pos_a = []
    byte_c=0
    byte_v=0
    bit_c=0
    byte_last_pos = 0
    unk_cnt = 0
    unk_pos_start = 0

    fn_skip = True
    dat_start = False
    dat_c = 0
    dat_head_c = 0

    #off_start = 8616353
    #off_start = 3440495
    #fn_skip = False
    #dat_start = True


    pos=off_start
    while pos<data_len-gv.chunk_win-batch_size:
        # 同步区检测
        #if dat_start==False and pos-off_start>gv.chunk_max*8*256*gv.chunk_byte_max_rate//100:
        #    print("格式错误 数据不能同步", pos-off_start, gv.chunk_max*8*256*gv.chunk_byte_max_rate//100)
        #    return []

        m = mark_a[pos]
        # 如果当前位置标识没有识别，则连续识别 batch_size 个标识
        if mark_a[pos] == gv.m_unset or mark_s_a[pos] == gv.m_unset:
            dat = data[pos:pos+gv.chunk*2+batch_size]
            m = classif(dat,pos)
            #dat = data[pos:pos+gv.chunk_wide]
            #dat = input_data_interp(dat,gv.chunk_wide,input_dim)
            #dat = [dat]

        mm = mark_s_a[pos]
        next_pos = mark_s_n(mm)
        if m==gv.m_unk:
            if unk_cnt==0:
                unk_pos_start = pos
            unk_cnt += 1
            if unk_cnt>=gv.chunk:
                print("unk", unk_cnt, unk_pos_start, pos)
                #unk_cnt = 0
            #if unk_cnt>gv.chunk:
            #print("unk", pos-gv.chunk)
            #plt_data_win(snd[pos-gv.chunk:pos-gv.chunk+gv.chunk_wide],-1.0,1.0)
            pos+=1
        else:
            unk_cnt = 0
            #print(m,end='')
            print(mark_flag(m),end='')
            print(mark_s_flag(mm),end='')
            if (m==gv.m_0 or m==gv.m_1) and bit_c==0:
                byte_pos_start=pos

            if verbose and (m==gv.m_0 or m==gv.m_1):
                #if dat_start==False: print("[%d]"%pos,end='')
                None

            # 同步 0 不能0开头
            if dat_start==False and m==gv.m_0 and (not byte_v in [1,2,4,8,16,32,64,128,0x7F]):
                print("同步 Syn 0", pos)
                if len(buf)>0:
                    print("丢弃0x80数量",len(buf))
                byte_c = 0
                bit_c = 0
                byte_v = 0
                pos_a = []
                buf = []
                #丢弃0
                m=gv.m_unk
            # 同步 1 只能是连续1结尾
            if dat_start==False and m==gv.m_1 and (not byte_v in [0,1,3,7,0x0F,0x1F,0x3F]):
                byte_c = 0
                bit_c = 0
                byte_v = 0
                pos_a = []
                buf = []
                byte_pos_start = pos
                print("同步 Syn 1", pos)
            if m==gv.m_0:
                bit_a[bit_c] = pos
                bit_s_a[bit_c] = next_pos
                bit_c += 1
                byte_v = byte_v*2
            if m==gv.m_1:
                bit_a[bit_c] = pos
                bit_s_a[bit_c] = next_pos
                bit_c += 1
                byte_v = byte_v*2+1
            if bit_c==8:
                bit_c = 0
                if dat_start==False and byte_v==0xFE:
                    dat_start = True
                # pos-byte_pos_start 是 7bit 占的数据宽度
                byte_dlen = (pos-byte_pos_start)*8//7
                chunk_avg = (pos-byte_pos_start)//7

                if verbose:
                    if dat_start==False:
                        print(" 同步", end="")
                    print(" [%04X %02X]"%(dat_c-dat_head_c+17+2+1, byte_v), byte_dlen, byte_pos_start - byte_last_pos, "%d%%"%(pos*100//data_len), byte_c, dat_c, byte_pos_start, pos+chunk_cur, end=" ")
                    #print("chunk %d %d [%d<%d<%d]"%(gv.chunk_init, chunk_avg, gv.chunk_min, chunk_cur, gv.chunk_max), chunk_cur*8, end=" ")
                    print("avg %d [%d<%d<%d]"%(chunk_avg, gv.chunk_min, chunk_cur, gv.chunk_max), chunk_avg_cur*8)

                else:
                    if dat_start==False:
                        print(" 同步", end="")
                    print(" %02X" % byte_v, dat_c, end=" ")
                    print(pos*100//data_len, "%", sep="")


                # 用来动态调整 chunk_cur
                chunk_next_bit = (pos-byte_pos_start)*gv.chunk_time_rate//(100*7)
                if chunk_cur>chunk_next_bit and chunk_cur>gv.chunk_min:
                    chunk_cur-=1
                if chunk_cur<chunk_next_bit and chunk_cur<gv.chunk_max:
                    chunk_cur+=1

                # 用来动态调整 chunk_avg_cur
                if chunk_avg_cur>chunk_avg and chunk_avg_cur>gv.chunk_min:
                    chunk_avg_cur-=1
                if chunk_avg_cur<chunk_avg and chunk_avg_cur<gv.chunk_max:
                    chunk_avg_cur+=1

                byte_dlen_max = chunk_avg_cur*8*gv.chunk_byte_max_rate//100

                '''
                if file_id==1:
                    if dat_c==11: print(dat_c); chunk_cur = 28
                    if dat_c==12: print(dat_c); chunk_cur = 35
                    if dat_c==86: print(dat_c); chunk_cur = 28
                    if dat_c==87: print(dat_c); chunk_cur = 35
                '''

                None

                # 如果 识别的第一个字节不是 0x80，试着把数据反转后再试
                #if byte_c==0 and byte_v!=0x80:
                #    print("识可能有问题", byte_pos_start, byte_dlen, gv.chunk_byte, len(buf))
                #    break
                byte_last_pos = byte_pos_start
                pos_a.append((byte_pos_start, byte_dlen))
                #if byte_dlen>gv.chunk_byte or (len(buf)<128 and byte_v!=0x80):
                #if byte_dlen>byte_dlen_max or (len(buf)<128 and byte_v!=0x80):
                if byte_dlen>byte_dlen_max or (len(buf)==0 and byte_v!=0x80):
                    print("可能有问题", byte_pos_start, byte_dlen, byte_dlen_max, len(buf), *[a+chunk_cur for a in bit_a])
                byte_c += 1
                buf.append(byte_v)
                #print("", chunk_cur, *[[a, a+b] for a, b in zip(bit_a, bit_s_a)], *[a-b for a, b in zip(bit_a[1:8], bit_a[0:7])])
                #print("", chunk_cur, *sum([[a, a+b] for a, b in zip(bit_a, bit_s_a)],[]), *[a-b for a, b in zip(bit_a[1:8], bit_a[0:7])])
                print("", chunk_cur, *sum([[n, a, a+b, c-a] for n, a, b, c in zip(range(8), bit_a, bit_s_a, bit_a[1:8]+bit_a[7:8])],[]) )


                if dat_start:
                    dat_c+=1

                # 跳过文件名后的空白
                if fn_skip and byte_v == 1:
                    print("Head 数据有误", pos, byte_v)
                if fn_skip and byte_v in [0,1]:
                    fn_skip = False
                    pos+=gv.chunk_skip_min
                    dat_head_c = dat_c
                    print("skip",gv.chunk_skip_min,pos+chunk_cur)

                byte_v = 0

            if m==gv.m_blk:
                if verbose: print("blk", pos, pos+chunk_cur)
                if bit_c!=0:
                    print("识别有问题", bit_c, byte_pos_start, pos)
                    print(*bit_a[:bit_c])
                    print("丢弃位数", bit_c)
                    bit_c = 0
                    byte_v = 0
                    if dat_start:
                        return buf
                #if verbose: plt_data_win(snd[pos:pos+gv.chunk_wide],-1.0,1.0)

            #pos+=chunk_cur
            pos+=next_pos

    if bit_c!=0:
        print("格式错误 bit 未对齐", bit_c)
        return buf

    return buf


# 用于文件名多余的信息
vz_info_s = ""

def dat2vz(buf):
    global vz_info_s

    vz_buf = []
    vz_info_s = ""

    dat_len = len(buf)

    #同步和前导：超过128个 0x80 5个 0xFE

    cnt_head = 0
    cnt_head_80 = 0
    for _ in range(dat_len):
        if buf[cnt_head] != 0x80: break
        cnt_head += 1
        cnt_head_80 += 1

    cnt_head_FE = 0
    for _ in range(dat_len-cnt_head_80):
        if buf[cnt_head] != 0xFE: break
        cnt_head += 1
        cnt_head_FE += 1

    '''
        for i in range(cnt_head):
            if h[i]!=buf[i]:
                print( i, pos_a[i], gv.chunk_byte, "%02X %02X" % (h[i], buf[i]))
                pos, dlen = pos_a[i]
                plot_wave(snd[pos:pos+dlen])
        quit()
    '''

    #if cnt_head_80<128:
    if cnt_head_80<100:
        print("Head 格式错误 同步 0x80 长度不够", cnt_head_80, dat_len)

    if cnt_head_80==0:
        return vz_buf

    if cnt_head_FE!=5:
        print("Head 格式错误 同步 0xFE 长度不够", cnt_head_FE, dat_len)
        return vz_buf

    print("Head 同步 OK")

    buf = buf[cnt_head:]
    dat_len = len(buf)

    if dat_len<1+17+2+2+2:
        print("Info 格式错误 数据长度不够", dat_len)
        return vz_buf

    c = 0

    sum = 0
    #sum = 0xFF00

    vzf_filename = [0 for _ in range(17)]
    vzf_dat = []

    vzf_type = buf[c]
    c+=1

    cnt_head_fn = 0
    for i in range(17):
        if buf[c] in [0,1]:
            c+=1
            cnt_head_fn += 1
            break
        vzf_filename[i] = buf[c]
        c+=1
        cnt_head_fn += 1


    vzf_startaddr_l = buf[c]
    vzf_startaddr_h = buf[c+1]

    vz_start = (buf[c+1]<<8)+buf[c]
    sum += buf[c] + buf[c+1]
    c+=2

    vz_end = (buf[c+1]<<8)+buf[c]
    sum += buf[c] + buf[c+1]
    c+=2

    vzf_dat_len = vz_end - vz_start
    print("Head ", "开始 %04X"%vz_start, "结束 %04X"%vz_end, vzf_dat_len)

    if verbose:
        for i in range(vzf_dat_len):
            if c+i<dat_len: print("%02X " % buf[c+i], end='')
        print()

    if dat_len < c + vzf_dat_len + 2:
        print("Data 格式错误 数据长度不够", cnt_head_80, cnt_head_FE, cnt_head_fn, vzf_dat_len, cnt_head_80+cnt_head_FE + 1 + cnt_head_fn + 2 + 2 + vzf_dat_len + 2, dat_len)
        vz_info_s += ".err_len_%d_%d"%(dat_len, 1 + cnt_head_fn + 2 + 2 + vzf_dat_len + 2)

    for _ in range(vzf_dat_len):
        if c>=dat_len: break
        vzf_dat.append(buf[c])
        sum+=buf[c]
        c+=1


    # 数据校验
    if c+2<=dat_len:
        vz_sum = (buf[c+1]<< 8)+buf[c]
        c+=2

        sum = sum & 0xFFFF

        if verbose: print("Data 数据校验", "sum %04X"%sum, "chk %04X"%vz_sum)

        #if not (vz_sum==sum or vz_sum==0):
        if vz_sum!=sum:
            print("Data 格式错误 数据校验错误", "sum %04X"%sum, "chk %04X"%vz_sum)
            vz_info_s += ".err_sum_%04X_%04X"%(sum,vz_sum)
        else:
            vz_info_s += ".%04X"%(sum)


    # 尾部多余数据
    vz_tail = dat_len-c

    for i in range(vz_tail):
        if buf[c]!=0:
            print("Tail 格式错误 末尾不为0", i, buf[c])
        c+=1

    print("校对完成", cnt_head_80, cnt_head_FE, cnt_head_fn, vzf_dat_len, vz_tail, cnt_head_80+cnt_head_FE+1+cnt_head_fn+2+2+vzf_dat_len+2+vz_tail, "处理数据长度", c)

    #vzf_magic = [0x20, 0x20, 0x00, 0x00]
    vzf_magic = [0x56, 0x5A, 0x46, 0x30]

    vz_buf = []
    vz_buf.extend(vzf_magic)
    vz_buf.extend(vzf_filename)
    vz_buf.append(vzf_type)
    vz_buf.append(vzf_startaddr_l)
    vz_buf.append(vzf_startaddr_h)
    vz_buf.extend(vzf_dat)

    return vz_buf

def scan_dir():
    global snd, mark_a, mark_s_a, chunk_cur, chunk_avg_cur, vz_info_s
    filename_lst = os.listdir(in_filepath) #得到文件夹下的所有文件名称

    for base_name in filename_lst:
        fn = in_filepath+pathsep+base_name
        file_name, fn_ext = os.path.splitext(base_name)
        if not os.path.isfile(fn): continue
        if fn_ext.lower()!=".wav": continue

        print(fn)
        sig, sample_rate, n_channels, n_frames = wavfile_read(fn)
        #sample_rate, sig = wavfile.read(in_filepath+pathsep+base_name)
        print("采样率: {}  数据量: {}  数据格式: {} 时间: {} 秒".format(sample_rate, sig.shape, sig.dtype, n_frames//sample_rate))
        # print(sig)
        # nchannels:声道数 sampwidth:量化位数（byte）framerate:采样频率 nframes:采样点数
        # 采样频率:每秒钟采集多少个信号样本

        '''
        if sig.dtype == np.uint8:
            print("PCM8位整数")
        if sig.dtype == np.int16:
            print("PCM16位整数")
        if sig.dtype == np.int32:
            print("PCM32位整数")
        if sig.dtype == np.float32:
            print("PCM32位浮点")
        '''

        #声道选择
        # 不支持多音轨
        # 只处理第一个声道
        if n_channels>1:
            snd = sig[:,0]
        else:
            snd = sig

        wav_chunk(sample_rate)
        mark_a = [gv.m_unset for _ in range(n_frames)]
        mark_s_a = [gv.m_unset for _ in range(n_frames)]

        # 载入已经标注过的点，减少标记过的点的误判。不是必须
        '''
        idx_fn = idx_filepath+pathsep+file_name+".jsonl"
        if os.path.isfile(idx_fn):
            cnt=0
            with jsonlines.open(idx_fn) as reader:
                for obj in reader:
                    #print(obj)
                    for k,v in obj.items():
                        #print(k, v)
                        #dat_mark(int(k),))
                        mark_a[int(k)]= v
                        cnt+=1
            print(idx_fn, cnt)

        idx_s_fn = idx_filepath+pathsep+file_name+".s.jsonl"
        if os.path.isfile(idx_s_fn):
            cnt=0
            with jsonlines.open(idx_s_fn) as reader:
                for obj in reader:
                    #print(obj)
                    for k,v in obj.items():
                        #print(k, v)
                        #dat_mark(int(k),))
                        mark_s_a[int(k)]= v
                        cnt+=1
            print(idx_s_fn, cnt)
        '''

        chunk_cur = gv.chunk_init
        chunk_avg_cur = gv.chunk

        if verbose:
            print(gv.chunk, gv.chunk_step, gv.chunk_step_min, chunk_cur)

        #标准化，使数据在-1.0，1.0之间
        data = wav_dtype_to_float32(snd)

        #print(data.dtype)

        # TH 阈值 - Threshold
        # 低于TH，认为是静音
        #TH = 0.05
        TH = 0.1

        clip_len = gv.chunk*8
        #找到有声音的位置
        rms = np_rms(data, clip_len)
        off_start=0
        cnt = len(rms)
        while off_start<cnt:
            #print(rms[off_start])
            if rms[off_start]>TH: break
            off_start += 1

        #if off_start>0: off_start=off_start-1
        off_start = off_start*clip_len

        # 跳过个别文件的杂音部分
        #off_start = 10000
        #off_start = 30000
        off_start = 60000
        '''
        if file_id==1:
            off_start = 60000
        '''

        print("start",off_start)

        #f = open("buf.bin", "rb")
        #buf = f.read()
        #f.close()
        #buf = list(buf)

        buf = recog_data(data, off_start)
        # 如果 识别的第一个字节不是 0x80，试着把数据反转后再试
        #if len(buf)==0:
        #    data = [-d for d in data]
        #    buf = recog_data(data, off_start)

        if len(buf)==0:
            continue

        vz_bin = buf

        vz_buf = dat2vz(buf)

        if len(vz_buf)>0:
            vz_fn = out_filepath+pathsep+file_name+vz_info_s+".vz"
            print(vz_fn)
            with open(vz_fn,'wb') as f:
                f.write(bytes(vz_buf))

        if len(vz_bin)>0:
            bin_fn = out_filepath+pathsep+file_name+vz_info_s+".bin"
            print(bin_fn)
            with open(bin_fn,'wb') as f:
                f.write(bytes(vz_bin))

        #quit()


def classif(dat,pos):
    #X = [[dat]]
    global mark_a, mark_s_a
    X = []
    for i in range(batch_size):
        #d = dat[i:i+gv.chunk_wide]
        #d = input_data_interp(d,gv.chunk_wide,input_dim)
        d = dat[i:i+gv.chunk_win]
        d = input_data_interp(d,gv.chunk_win,input_dim)
        X.append([d])

    X = np.array(X,dtype=np_dtype)
    #print(X.shape)
    #quit()
    X = torch.tensor(X)

    X = X.to(device)

    model_s.eval()
    model.eval()

    pred = model_s(X).argmax(1)
    a = pred.cpu().numpy()
    a = a.tolist()
    for i in range(batch_size):
        if mark_s_a[pos+i]==gv.m_unset:
            mark_s_a[pos+i] = a[i] 

    pred = model(X).argmax(1)
    a = pred.cpu().numpy()
    a = a.tolist()
    for i in range(batch_size):
        if mark_a[pos+i]==gv.m_unset:
            mark_a[pos+i] = a[i] 

    return a[0]


if __name__ == "__main__":
    model_s.load_state_dict(torch.load(model_s_dict_fn))
    model_s.eval()

    model.load_state_dict(torch.load(model_dict_fn))
    model.eval()

    scan_dir()

    #parser = argparse.ArgumentParser()
    #parser.add_argument('fn', type=str, help='filename')
    #args = parser.parse_args()
    #print(args)
    #train_data(args.fn)
